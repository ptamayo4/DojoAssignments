from django.shortcuts import render, redirect
from datetime import datetime
from django.contrib import messages
from models import User, Trip
from datetime import date
import datetime

def index(request):
    if 'id' in request.session:
        return redirect('/travels')
    return render(request, 'index.html')

def register(request):
    if request.method == "POST":
        user = User.userManager.add_user(request.POST)
        if 'errors' in user:
            for error in user['errors']:
                messages.error(request,  error)
            return redirect('/')
        else:
            request.session['id'] = user['theuser'].id
            return redirect('/travels')
    return redirect('/')

def login(request):
    if request.method == "POST":
        user = User.userManager.login(request.POST)
        if 'errors' in user:
            for error in user['errors']:
                messages.error(request, error)
            return redirect('/')
        else:
            request.session['id'] = user['theuser'].id
            return redirect('/travels')

def logout(request):
    if 'id' in request.session:
        del request.session['id']
        return redirect('/main')
    return redirect('/main')

def travels(request):
    context = {
        "name": User.userManager.get(id=request.session['id']).name,
        "my_trips": Trip.tripManager.filter(user__id=request.session['id']),
        "user_trips": Trip.tripManager.all().exclude(organizer__id=request.session['id'])
    }
    return render(request, 'travels.html', context)

def tripview(request, id):
    organizer = Trip.tripManager.get(id=id).organizer
    print organizer.id
    context = {
        "trip":Trip.tripManager.get(id=id),
        "others":User.userManager.filter(trips__id=id).exclude(id=organizer.id)
    }
    return render(request, 'tripview.html', context)

def trip_adder(request):
    return render(request, 'tripadder.html')

def trip_process(request):
    if request.method == "POST":
        trip = Trip.tripManager.add_trip(request.POST)
        if 'errors' in trip:
            for error in trip['errors']:
                messages.error(request, error)
            return render(request, 'tripadder.html')
        else:
            return redirect('/')
    return render(request, 'tripadder.html')

def joiner(request, id):
    trip = Trip.tripManager.get(id=id)
    user = User.userManager.get(id=request.session['id'])
    trip.user.add(user)
    return redirect('/')
