from __future__ import unicode_literals
from django.db import models
import re
import bcrypt
from datetime import date
import datetime


class UserManager(models.Manager):
    def add_user(self, post_data):
        error_msgs = []
        if User.userManager.filter(username=post_data['username']):
            error_msgs.append("Username Taken")
        if len(post_data['name']) < 3:
            error_msgs.append("Name is too short")
        if len(post_data['username']) < 3:
            error_msgs.append("Username is too short")
        if len(post_data['password']) < 8:
            error_msgs.append("Password is too short")
        if post_data['password'] != post_data['confirm_password']:
            error_msgs.append("Passwords don't match")

        if error_msgs:
            return {"errors":error_msgs}
        else:
            encoded = post_data['password'].encode()
            new_user = User.userManager.create(
                name    =   post_data['name'],
                username   =   post_data['username'],
                password=   bcrypt.hashpw(encoded, bcrypt.gensalt())
            )
            return {"theuser": new_user}

    def login(self, post_data):
        error_msgs = []
        if User.userManager.filter(username=post_data['username']):
            hashed = User.userManager.get(username=post_data['username']).password
            hashed = hashed.encode()
            user_pass = post_data['password'].encode()
            if bcrypt.hashpw(user_pass,hashed) == hashed:
                print "Successful PASSWORD!!"
                return {"theuser": User.userManager.get(username=post_data['username'])}
            else:
                print "Bad Password!"
                error_msgs.append("Invalid Login")
                return {"errors":error_msgs}
        else:
            print "bad username"
            error_msgs.append("Invalid Login")
            return {"errors":error_msgs}

class TripManager(models.Manager):
    def add_trip(self, post_data):
        start = post_data['start_date']
        start = datetime.datetime.strptime(start, '%Y-%m-%d')
        start = start.date()

        end = post_data['end_date']
        end = datetime.datetime.strptime(end, '%Y-%m-%d')
        end = end.date()
        error_msgs = []
        if len(post_data['destination']) < 1:
            error_msgs.append("Destination cannot be blank")
        if len(post_data['description']) < 1:
            error_msgs.append("Description cannot be blank")
        if start < date.today():
            error_msgs.append("Start date cannot be in the past")
        if end < date.today():
            error_msgs.append("End date cannot be in the past")
        if start > end:
            error_msgs.append("End date must be after start date")

        if error_msgs:
            return {"errors":error_msgs}
        else:
            new_trip = Trip.tripManager.create(
            destination=post_data['destination'],
            plan=post_data['description'],
            start_date=post_data['start_date'],
            end_date=post_data['end_date'],
            organizer=User.userManager.get(id=post_data['curr_user']),
            )
            new_trip.user.add(User.userManager.get(id=post_data['curr_user']))
            return {"thetrip":new_trip}


class User(models.Model):
    name    =   models.CharField(max_length=100)
    username=   models.CharField(max_length=100)
    password=   models.CharField(max_length=100)
    userManager = UserManager()

class Trip(models.Model):
    destination =   models.CharField(max_length=100)
    start_date  =   models.DateField()
    end_date    =   models.DateField()
    user        =   models.ManyToManyField(User, related_name="trips")
    organizer   =   models.ForeignKey(User, related_name="my_trip")
    plan        =   models.TextField(max_length=1000)
    tripManager = TripManager()
