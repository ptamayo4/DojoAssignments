//
//  ViewController.swift
//  NinjaGold
//
//  Created by Patrick Tamayo on 4/5/17.
//  Copyright © 2017 Patrick Tamayo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var scoreLabel: UILabel!
    
    @IBOutlet weak var farmLabel: UILabel!
    @IBOutlet weak var caveLabel: UILabel!
    @IBOutlet weak var houseLabel: UILabel!
    @IBOutlet weak var casinoLabel: UILabel!
    
    var goldCount = 0
    
    @IBAction func buildingButtonPressed(_ sender: UIButton) {
        var gold = 0
        if sender.tag == 1 {
            gold = Int(arc4random_uniform(11)) + 10
            goldCount += gold
            updateUI()
            farmLabel.text = "You earned " + String(gold) + " gold"
        } else if sender.tag == 2 {
            gold = Int(arc4random_uniform(6)) + 5
            goldCount += gold
            updateUI()
            caveLabel.text = "You earned " + String(gold) + " gold"
        } else if sender.tag == 3 {
            gold = Int(arc4random_uniform(4)) + 2
            goldCount += gold
            updateUI()
            houseLabel.text = "You earned " + String(gold) + " gold"
        } else {
            let gamble = arc4random_uniform(2)
            if gamble == 1 {
                gold = Int(arc4random_uniform(51))
                goldCount += gold
                updateUI()
                casinoLabel.text = "You won " + String(gold) + " gold"
            } else {
                gold = -(Int(arc4random_uniform(51)))
                goldCount += gold
                updateUI()
                casinoLabel.text = "You lost " + String(-gold) + " gold"
            }
        }
        
    }
    
    @IBAction func resetButtonPressed(_ sender: UIButton) {
        goldCount = 0
        updateUI()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func updateUI(){
        scoreLabel.text = "Score: " + String(goldCount)
        farmLabel.text = ""
        caveLabel.text = ""
        houseLabel.text = ""
        casinoLabel.text = ""
        
    }


}

