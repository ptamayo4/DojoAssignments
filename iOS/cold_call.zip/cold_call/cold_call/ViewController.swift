//
//  ViewController.swift
//  cold_call
//
//  Created by Patrick Tamayo on 4/4/17.
//  Copyright © 2017 Patrick Tamayo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let nameBank = ["Patrick", "Jessica", "Richard", "Michael", "Erika", "Irma", "Roland"]
    
    var nameCount = 0
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBAction func callButtonPressed(_ sender: UIButton) {
        updateUI()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    func updateUI(){
        let rand = arc4random_uniform(UInt32(nameBank.count))
        nameLabel.text = nameBank[Int(rand)]
    }


}

