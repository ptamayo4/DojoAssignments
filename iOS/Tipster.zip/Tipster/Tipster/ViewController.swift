//
//  ViewController.swift
//  Tipster
//
//  Created by Patrick Tamayo on 4/6/17.
//  Copyright © 2017 Patrick Tamayo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var subtotalString: String = ""
    var currSubTotal: Double = 0.0
    var group = 1
    var val = 15
    
    @IBOutlet var allLabels: [UILabel]!
    
    @IBOutlet var buttonPressed: [UIButton]!
    
    @IBAction func buttonPressedAction(_ sender: UIButton) {
        if sender.tag >= 0 && sender.tag < 10 && subtotalString.characters.count < 10 {
            subtotalString += String(sender.tag)
            allLabels[0].text = subtotalString
            currSubTotal = Double(subtotalString)!
            updateUI()
        }
        if sender.tag == 11 && !(subtotalString.characters.contains(".")){
            subtotalString += "."
            allLabels[0].text = subtotalString
            updateUI()
        }
        if sender.tag == 10 {
            subtotalString = ""
            allLabels[0].text = subtotalString
            updateUI()

        }
    }
    
    @IBOutlet weak var groupLabel: UILabel!
    @IBOutlet weak var tipSlider: UISlider!
    
    @IBOutlet weak var groupSlider: UISlider!
    @IBAction func groupSliderChanged(_ sender: UISlider) {
        group = Int(sender.value)
        groupLabel.text = "Group Size: " + String(group)
        updateUI()
        
    }
    @IBAction func tipSliderChanged(_ sender: UISlider) {
        val = Int(sender.value)
        updateUI()
    }
    
    func updateUI(){
        //Header Percentages
        allLabels[1].text = "\(val)%"
        allLabels[2].text = "\(val + 5)%"
        allLabels[3].text = "\(val + 10)%"
        
        //Tip Amounts
        allLabels[4].text = String(round((currSubTotal * (Double(val) / 100)) / Double(group) * 100) / 100)
        allLabels[5].text = String(round((currSubTotal * (Double(val + 5) / 100)) / Double(group) * 100) / 100)
        allLabels[6].text = String(round((currSubTotal * (Double(val + 10) / 100)) / Double(group) * 100 / 100))
        
        //Total Amounts
        allLabels[7].text = String(round((currSubTotal + currSubTotal * (Double(val) / 100)) / Double(group) * 100) / 100)
        allLabels[8].text = String(round((currSubTotal + currSubTotal * (Double(val + 5) / 100)) / Double(group) * 100) / 100)
        allLabels[9].text = String(round((currSubTotal + currSubTotal * (Double(val + 10) / 100)) / Double(group) * 100) / 100)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for label in allLabels{
            label.text = "0.0"
        }
        allLabels[1].text = "15%"
        allLabels[2].text = "20%"
        allLabels[3].text = "25%"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    


}

