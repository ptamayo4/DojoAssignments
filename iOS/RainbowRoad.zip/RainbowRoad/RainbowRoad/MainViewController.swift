//
//  ViewController.swift
//  RainbowRoad
//
//  Created by Patrick Tamayo on 4/10/17.
//  Copyright © 2017 Patrick Tamayo. All rights reserved.
//

import UIKit

class MainViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var arr = ["1","2","3"]
    var cellArr: [UIColor] = [UIColor]()


    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        cellArr.append(UIColor.red)
        cellArr.append(UIColor.orange)
        cellArr.append(UIColor.yellow)
        cellArr.append(UIColor.green)
        cellArr.append(UIColor.blue)
        cellArr.append(UIColor.purple)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cellArr.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        cell.backgroundColor = cellArr[indexPath.row]
        return cell
    }
}
