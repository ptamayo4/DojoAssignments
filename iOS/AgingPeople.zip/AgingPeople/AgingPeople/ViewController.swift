//
//  ViewController.swift
//  AgingPeople
//
//  Created by Patrick Tamayo on 4/10/17.
//  Copyright © 2017 Patrick Tamayo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var arr = ["Patrick", "Jessica", "Richard", "Michael",
               "Erika", "Cody", "Jeff", "Andrew", "Kevin",
               "Chris", "Kelly", "Mitch", "Dylan"]
    
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        
        
        cell.textLabel?.text = arr[indexPath.row]
        cell.detailTextLabel?.text = String(Int(arc4random_uniform(91)) + 5) + " years old"
        return cell
    }
    
}

