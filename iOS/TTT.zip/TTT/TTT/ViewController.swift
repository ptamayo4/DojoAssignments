//
//  ViewController.swift
//  TTT
//
//  Created by Patrick Tamayo on 4/5/17.
//  Copyright © 2017 Patrick Tamayo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var winnerLabel: UILabel!
    
    var red:[Int] = [Int]()
    var blue:[Int] = [Int]()
    var player = 0
    
    //Winning Combos
    var win = [[1,2,3],[4,5,6],[7,8,9],[1,5,9],[3,5,7],[1,4,7],[2,5,8],[3,6,9]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        winnerLabel.text = ""
    }

    @IBAction func resetButtonPressed(_ sender: UIButton) {
        for button in buttonPressed{
            button.backgroundColor = UIColor.black
        }
        red = []
        blue = []
        player = 0
        winnerLabel.text = ""
    }
    

    @IBOutlet var buttonPressed: [UIButton]!
    
    
    @IBAction func buttonPressAction(_ sender: UIButton) {
        //0 means it's red's turn, 1 blue, changed to 42 after game over, resets upin reset button
        //Need to check to see if button already pressed
        if !(red.contains(sender.tag)) && !(blue.contains(sender.tag)){
            if player == 0 {
                sender.backgroundColor = UIColor.red
                red.append(sender.tag)
                player = 1
                winnerLabel.text = "Blue's Turn"
            } else if player == 1 {
                sender.backgroundColor = UIColor.blue
                blue.append(sender.tag)
                player = 0
                winnerLabel.text = "Red's Turn"
            }
        }
        getGameState()
    }
    
    //Compare current arrays to winning combos
    func getGameState(){
        var winCount = 0
        if red.count + blue.count == 9 {
            winnerLabel.text = "Draw!!"
            player = 42
        }
        if red.count >= 3 || blue.count >= 3 {
            for w in win {
                winCount = 0
                for num in red {
                    if w.contains(num){
                        winCount += 1
                        if winCount == 3 {
                            winnerLabel.text = "Red is the Winner!"
                            player = 42
                        }
                    }
                }
            }
            for w in win {
                winCount = 0
                for num in blue {
                    if w.contains(num){
                        winCount += 1
                        if winCount == 3 {
                            winnerLabel.text = "Blue is the Winner!"
                            player = 42
                        }
                    }
                }
            }
        }
    }
}

