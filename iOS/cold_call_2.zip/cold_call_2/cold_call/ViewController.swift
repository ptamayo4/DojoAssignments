//
//  ViewController.swift
//  cold_call
//
//  Created by Patrick Tamayo on 4/4/17.
//  Copyright © 2017 Patrick Tamayo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let nameBank = ["Patrick", "Jessica", "Richard", "Michael", "Erika"]
    
    var nameCount = 0
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numLabel: UILabel!
    
    @IBAction func callButtonPressed(_ sender: UIButton) {
        updateUI()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    func updateUI(){
        let rand = arc4random_uniform(UInt32(nameBank.count))
        nameLabel.text = nameBank[Int(rand)]
        numLabel.text = String(rand + 1)
        if rand + 1 == 5 {
            numLabel.textColor = UIColor.green
        } else if rand + 1 > 2 {
            numLabel.textColor = UIColor.orange
        } else {
            numLabel.textColor = UIColor.red
        }
    }


}

